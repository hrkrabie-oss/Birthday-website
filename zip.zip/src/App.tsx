/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AnimatePresence } from "motion/react";
import { useState } from "react";
import { Background } from "./components/Background";
import { ProgressBar } from "./components/ProgressBar";
import { Step1, Step2, Step3, Step4, Step5 } from "./components/Steps";
import confetti from "canvas-confetti";

export default function App() {
  const [currentStep, setCurrentStep] = useState(1);
  const [isFinale, setIsFinale] = useState(false);
  const totalSteps = 5;

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const triggerFinale = () => {
    setIsFinale(true);
    
    // Bottom corners burst
    const end = Date.now() + 5 * 1000;
    const colors = ['#ff4d6d', '#c8b6ff', '#ffffff', '#ffd60a'];

    (function frame() {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 1 },
        colors: colors
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 1 },
        colors: colors
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    }());

    // Heart emoji confetti shower
    const scalar = 2;
    const heart = confetti.shapeFromText({ text: '❤️', scalar });
    const sparkle = confetti.shapeFromText({ text: '✨', scalar });
    const star = confetti.shapeFromText({ text: '💖', scalar });

    setTimeout(() => {
      confetti({
        particleCount: 50,
        spread: 100,
        origin: { y: 0.1 },
        shapes: [heart, sparkle, star],
        scalar
      });
    }, 1000);
    
    setTimeout(() => {
      confetti({
        particleCount: 50,
        spread: 100,
        origin: { y: 0.1 },
        shapes: [heart, sparkle, star],
        scalar
      });
    }, 2500);
  };

  return (
    <div className="relative min-h-screen w-full font-sans text-white overflow-hidden selection:bg-pink-500/30">
      <Background isFinale={isFinale} />
      
      <ProgressBar step={currentStep} totalSteps={totalSteps} />

      <main className="relative z-10 w-full min-h-screen flex items-center justify-center p-4">
        <AnimatePresence mode="wait">
          {currentStep === 1 && <Step1 key="step1" onNext={nextStep} />}
          {currentStep === 2 && <Step2 key="step2" onNext={nextStep} />}
          {currentStep === 3 && <Step3 key="step3" onNext={nextStep} />}
          {currentStep === 4 && <Step4 key="step4" onNext={nextStep} />}
          {currentStep === 5 && <Step5 key="step5" onFinale={triggerFinale} isFinale={isFinale} />}
        </AnimatePresence>
      </main>
    </div>
  );
}
