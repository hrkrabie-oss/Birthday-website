import { motion, HTMLMotionProps } from "motion/react";
import { cn } from "../lib/utils";

interface ButtonProps extends HTMLMotionProps<"button"> {
  children: React.ReactNode;
}

export function Button({ children, className, ...props }: ButtonProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.05, y: -2 }}
      whileTap={{ scale: 0.95, y: 0 }}
      className={cn(
        "px-8 py-3 rounded-full font-sans font-medium text-white",
        "bg-gradient-to-r from-pink-500 to-rose-500",
        "shadow-[0_0_15px_rgba(244,63,94,0.4)]",
        "hover:shadow-[0_0_25px_rgba(244,63,94,0.6)]",
        "transition-shadow duration-300",
        "disabled:opacity-50 disabled:pointer-events-none",
        className
      )}
      {...props}
    >
      {children}
    </motion.button>
  );
}
