import { motion } from "motion/react";
import { cn } from "../lib/utils";

export function StepCard({ children, className }: { children: React.ReactNode, className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -30, scale: 0.95 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        "relative w-full max-w-lg p-8 md:p-10",
        "bg-stone-950/40 backdrop-blur-xl",
        "border border-white/10 rounded-3xl",
        "shadow-[0_20px_40px_rgba(0,0,0,0.4)]",
        "flex flex-col items-center text-center gap-6",
        className
      )}
    >
      {children}
    </motion.div>
  );
}
