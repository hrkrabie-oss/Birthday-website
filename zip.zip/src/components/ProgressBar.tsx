import { motion } from "motion/react";
import { cn } from "../lib/utils";

export function ProgressBar({ step, totalSteps }: { step: number; totalSteps: number }) {
  const progress = (step / totalSteps) * 100;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 w-[90%] max-w-md h-1.5 bg-white/10 backdrop-blur-md rounded-full overflow-hidden z-50 shadow-[0_0_10px_rgba(255,255,255,0.1)] border border-white/5">
      <motion.div 
        className="h-full bg-gradient-to-r from-pink-500 to-rose-500 rounded-full shadow-[0_0_10px_rgba(244,63,94,0.5)]"
        initial={{ width: 0 }}
        animate={{ width: `${progress}%` }}
        transition={{ duration: 0.5, ease: "easeInOut" }}
      />
    </div>
  );
}
