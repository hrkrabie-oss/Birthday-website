import { Canvas, useFrame } from '@react-three/fiber';
import { useMemo, useRef, useState, useEffect } from 'react';
import * as THREE from 'three';

function Heart({ position, scale, rotation, speed, isEnding }: any) {
  const mesh = useRef<THREE.Mesh>(null);
  
  const shape = useMemo(() => {
    const x = 0, y = 0;
    const heartShape = new THREE.Shape();
    heartShape.moveTo( x + 5, y + 5 );
    heartShape.bezierCurveTo( x + 5, y + 5, x + 4, y, x, y );
    heartShape.bezierCurveTo( x - 6, y, x - 6, y + 7,x - 6, y + 7 );
    heartShape.bezierCurveTo( x - 6, y + 11, x - 3, y + 15.4, x + 5, y + 19 );
    heartShape.bezierCurveTo( x + 12, y + 15.4, x + 16, y + 11, x + 16, y + 7 );
    heartShape.bezierCurveTo( x + 16, y + 7, x + 16, y, x + 10, y );
    heartShape.bezierCurveTo( x + 7, y, x + 5, y + 5, x + 5, y + 5 );
    return heartShape;
  }, []);

  const extrudeSettings = useMemo(() => ({
    depth: 2,
    bevelEnabled: true,
    bevelSegments: 2,
    steps: 2,
    bevelSize: 1,
    bevelThickness: 1
  }), []);

  const [t] = useState(() => Math.random() * 100);

  useFrame((state) => {
    if (mesh.current) {
      if (isEnding) {
        // Swirl outwards and up
        mesh.current.position.y += speed * 3;
        mesh.current.position.x += Math.sin(state.clock.elapsedTime * 2 + t) * speed;
        mesh.current.rotation.z += 0.05;
      } else {
        mesh.current.position.y += Math.sin(state.clock.elapsedTime * speed + t) * 0.01;
        mesh.current.rotation.y += 0.005;
        mesh.current.rotation.z = Math.sin(state.clock.elapsedTime * speed * 0.5 + t) * 0.1 + rotation[2];
      }
    }
  });

  return (
    <mesh ref={mesh} position={position} scale={scale} rotation={rotation}>
      <extrudeGeometry args={[shape, extrudeSettings]} />
      <meshStandardMaterial color="#ff4d6d" roughness={0.3} metalness={0.2} transparent opacity={isEnding ? 0 : 0.8} />
    </mesh>
  );
}

function HeartsScene({ isEnding }: { isEnding: boolean }) {
  const hearts = useMemo(() => {
    return Array.from({ length: 25 }).map((_, i) => ({
      position: [
        (Math.random() - 0.5) * 200,
        (Math.random() - 0.5) * 200,
        (Math.random() - 0.5) * 100 - 50,
      ] as [number, number, number],
      scale: (Math.random() * 0.2 + 0.1) * 0.15,
      rotation: [
        Math.PI, 
        0, 
        (Math.random() - 0.5) * 0.5
      ] as [number, number, number],
      speed: Math.random() * 0.5 + 0.1,
      id: i,
    }));
  }, []);

  return (
    <>
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 10]} intensity={1} color="#ffb3c6" />
      <directionalLight position={[-10, -10, -10]} intensity={0.5} color="#c8b6ff" />
      
      {hearts.map((props) => (
        <Heart key={props.id} {...props} isEnding={isEnding} />
      ))}
    </>
  );
}

export function Background({ isFinale }: { isFinale: boolean }) {
  return (
    <div className="fixed inset-0 z-[-1] overflow-hidden bg-stone-950">
      <div className="absolute inset-0 bg-stone-950 z-0"></div>
      
      {/* Aurora Layers */}
      <div className="absolute inset-0 z-10 opacity-60 mix-blend-screen overflow-hidden">
        <div className="absolute -inset-[100%] animate-aurora [background-image:radial-gradient(circle_at_50%_50%,hsla(333,70%,55%,0.4)_0%,transparent_50%),radial-gradient(circle_at_80%_20%,hsla(282,82%,54%,0.3)_0%,transparent_40%),radial-gradient(circle_at_20%_80%,hsla(210,89%,60%,0.3)_0%,transparent_50%),radial-gradient(circle_at_80%_80%,hsla(35,90%,60%,0.3)_0%,transparent_40%)]" />
      </div>

      <div className="absolute inset-0 z-20">
        <Canvas camera={{ position: [0, 0, 50], fov: 75 }}>
          <HeartsScene isEnding={isFinale} />
        </Canvas>
      </div>
    </div>
  );
}
