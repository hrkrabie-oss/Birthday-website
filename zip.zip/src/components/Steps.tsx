import { motion } from "motion/react";
import { StepCard } from "./StepCard";
import { Button } from "./Button";

export function Step1({ onNext }: { onNext: () => void }) {
  return (
    <StepCard>
      <motion.div 
        animate={{ scale: [1, 1.1, 1] }} 
        transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        className="text-6xl drop-shadow-[0_0_20px_rgba(244,63,94,0.8)]"
      >
        ❤️
      </motion.div>
      <h1 className="font-serif text-4xl md:text-5xl font-bold bg-gradient-to-br from-pink-200 via-white to-pink-200 bg-clip-text text-transparent">
        Hey Beautiful,
      </h1>
      <p className="font-sans text-stone-300 text-lg md:text-xl leading-relaxed">
        I built a little world for you, just to bring a smile to your face on your special day.
      </p>
      <div className="pt-4">
        <Button onClick={onNext}>Let's Begin</Button>
      </div>
    </StepCard>
  );
}

export function Step2({ onNext }: { onNext: () => void }) {
  return (
    <StepCard>
      <div className="text-6xl drop-shadow-[0_0_20px_rgba(255,255,255,0.4)]">
        🎉
      </div>
      <h1 className="font-serif text-4xl md:text-5xl font-bold bg-gradient-to-br from-pink-200 via-white to-pink-200 bg-clip-text text-transparent">
        Happy Birthday!
      </h1>
      <p className="font-sans text-stone-300 text-lg md:text-xl leading-relaxed">
        Another year of you making the world brighter. Your existence is a gift, and I'm so lucky to witness it.
      </p>
      <div className="pt-4">
        <Button onClick={onNext}>There's more...</Button>
      </div>
    </StepCard>
  );
}

export function Step3({ onNext }: { onNext: () => void }) {
  return (
    <StepCard className="max-w-2xl">
      <h2 className="font-serif text-3xl md:text-4xl font-bold bg-gradient-to-br from-pink-200 via-white to-pink-200 bg-clip-text text-transparent mb-2">
        A Few Things I Adore About You
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
        <div className="md:col-span-2 p-5 rounded-2xl bg-white/5 border border-white/5 text-left flex flex-col gap-2">
          <h3 className="font-serif text-xl text-white font-medium">✨ Your Unmatched Kindness</h3>
          <p className="font-sans text-stone-400 text-sm">The genuine warmth you show to everyone is something truly rare and beautiful.</p>
        </div>
        
        <div className="p-5 rounded-2xl bg-white/5 border border-white/5 text-left flex flex-col gap-2">
          <h3 className="font-serif text-xl text-white font-medium">😊 That Smile</h3>
          <p className="font-sans text-stone-400 text-sm">It's a work of art.</p>
        </div>
        
        <div className="md:col-span-2 p-5 rounded-2xl bg-white/5 border border-white/5 text-left flex flex-col gap-2">
          <h3 className="font-serif text-xl text-white font-medium">🌟 Your Radiant Spirit</h3>
          <p className="font-sans text-stone-400 text-sm">Your passion for life is infectious. Being around you makes everything feel more exciting and possible.</p>
        </div>
      </div>

      <div className="pt-4">
        <Button onClick={onNext}>Remember this?</Button>
      </div>
    </StepCard>
  );
}

export function Step4({ onNext }: { onNext: () => void }) {
  return (
    <StepCard>
      <h2 className="font-serif text-3xl md:text-4xl font-bold bg-gradient-to-br from-pink-200 via-white to-pink-200 bg-clip-text text-transparent">
        That One Time...
      </h2>
      
      <motion.div 
        whileHover={{ scale: 1.05, rotateY: 10, rotateX: -5 }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
        style={{ perspective: 1000 }}
        className="w-full max-w-sm mx-auto my-4"
      >
        <div className="bg-white p-4 pb-12 rounded-lg shadow-2xl rotate-[-2deg] transition-transform duration-300">
          <div className="aspect-[4/5] bg-stone-200 overflow-hidden relative">
            <img 
              src="https://i.ibb.co/6Z6XgCg/crush.webp" 
              alt="Our favorite memory" 
              className="w-full h-full object-cover"
            />
          </div>
          <p className="font-serif text-stone-800 text-xl text-center mt-6 rotate-[1deg]">
            Our favorite memory.
          </p>
        </div>
      </motion.div>

      <p className="font-sans text-stone-300 text-lg md:text-xl leading-relaxed">
        Every moment with you feels like a scene from a movie I'd watch on repeat.
      </p>
      
      <div className="pt-4">
        <Button onClick={onNext}>One last thing...</Button>
      </div>
    </StepCard>
  );
}

export function Step5({ onFinale, isFinale }: { onFinale: () => void; isFinale: boolean }) {
  return (
    <StepCard>
      <div className="text-6xl drop-shadow-[0_0_20px_rgba(255,255,255,0.4)]">
        🎂
      </div>
      <h1 className="font-serif text-4xl md:text-5xl font-bold bg-gradient-to-br from-pink-200 via-white to-pink-200 bg-clip-text text-transparent">
        My Wish For You
      </h1>
      <p className="font-sans text-stone-300 text-lg md:text-xl leading-relaxed">
        May the next year bring you all the love, success, and pure happiness you so rightfully deserve. May your dreams soar higher than ever.
      </p>
      
      <div className="h-16 flex items-center justify-center">
        {!isFinale ? (
          <Button onClick={onFinale}>Celebrate!</Button>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="font-serif text-3xl text-pink-400 font-bold"
          >
            Happy Birthday, my crush! ❤️
          </motion.div>
        )}
      </div>
    </StepCard>
  );
}
